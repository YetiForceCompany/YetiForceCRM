import App from './App.js'
import store from '/src/store/index.js'
import router from '/src/router/index.js'

Vue.use(Vuex)

new Vue({
  render: h => h(App),
  store,
  router: router({ store })
}).$mount('#app')
