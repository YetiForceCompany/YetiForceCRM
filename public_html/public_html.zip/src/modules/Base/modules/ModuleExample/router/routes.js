export default [
  {
    name: 'Base.ModuleExample',
    parent: 'Base',
    path: 'module-example',
    componentPath: 'pages/ModuleExample'
  }
]
