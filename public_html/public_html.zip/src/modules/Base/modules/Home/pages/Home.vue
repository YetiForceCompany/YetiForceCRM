<!-- /* {[The file is published on the basis of YetiForce Public License 3.0 that can be found in the following directory: licenses/LicenseEN.txt or yetiforce.com]} */ -->
<template>
  <div>Home page</div>
</template>

<style></style>

<script>
export default {
  name: 'Base.Home.Pages.Home'
}
</script>
