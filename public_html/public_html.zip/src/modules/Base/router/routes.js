export default [
  {
    name: 'Base',
    parent: 'App',
    path: '/',
    componentPath: 'layouts/Base'
  }
]
