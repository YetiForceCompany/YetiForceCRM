//
//

import ModuleLoader from '/src/ModuleLoader.js';
import store from './store/index.js';
import mutations from '/src/store/mutations.js';

var moduleName = 'Core.Env';
var __script__ = {
  name: moduleName,
  created: function created() {
    this.$store.registerModule(moduleName.split('.'), ModuleLoader.prepareStoreNames(moduleName, store));
    this.$store.commit(mutations.Core.Env.update, window.env.Env);
  }
};

var render = function render() {
  var _vm = this;var _h = _vm.$createElement;var _c = _vm._self._c || _h;
  return _c("div");
};
var staticRenderFns = [];
var __template__ = { render: render, staticRenderFns: staticRenderFns };

export default Object.assign({}, __script__, __template__);