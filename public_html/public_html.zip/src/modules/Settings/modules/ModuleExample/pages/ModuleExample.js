//
//
//
//
//
//
//

import Hook from '/src/modules/Core/modules/Hooks/components/Hook';

var moduleName = 'Settings.ModuleExample.Pages.ModuleExample';
var __script__ = {
  name: moduleName,
  components: { Hook: Hook }
};

var render = function render() {
  var _vm = this;var _h = _vm.$createElement;var _c = _vm._self._c || _h;
  return _c('div', [_c('hook', {
    attrs: {
      "name": "before"
    }
  }), _vm._v("Layout -> Settings -> ModuleExample page\n  "), _c('hook', {
    attrs: {
      "name": "after"
    }
  })], 1);
};
var staticRenderFns = [];
var __template__ = { render: render, staticRenderFns: staticRenderFns };

export default Object.assign({}, __script__, __template__);