//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

var __script__ = {
  name: 'YfCopyright'
};

var render = function render() {
  var _vm = this;var _h = _vm.$createElement;var _c = _vm._self._c || _h;
  return _c('div', [_c('div', [_vm._v("© YetiForce.com All rights reserved.")]), _vm._v(" "), _c('q-separator', {
    attrs: {
      "dark": ""
    }
  }), _vm._v(" "), _c('div', {
    staticClass: "flex no-wrap justify-between q-py-xs"
  }, [_c('a', {
    staticClass: "q-link text-inherit",
    attrs: {
      "href": "https://www.linkedin.com/groups/8177576",
      "rel": "noreferrer noopener"
    }
  }, [_c('q-icon', {
    attrs: {
      "size": "16px",
      "name": "mdi-linkedin",
      "title": "Linkedin"
    }
  })], 1), _vm._v(" "), _c('q-separator', {
    staticClass: "q-mx-sm",
    attrs: {
      "dark": "",
      "vertical": ""
    }
  }), _vm._v(" "), _c('a', {
    staticClass: "q-link text-inherit",
    attrs: {
      "href": "https://twitter.com/YetiForceEN",
      "rel": "noreferrer noopener"
    }
  }, [_c('q-icon', {
    attrs: {
      "size": "16px",
      "name": "mdi-twitter",
      "title": "Twitter"
    }
  })], 1), _vm._v(" "), _c('q-separator', {
    staticClass: "q-mx-sm",
    attrs: {
      "dark": "",
      "vertical": ""
    }
  }), _vm._v(" "), _c('a', {
    staticClass: "q-link text-inherit",
    attrs: {
      "href": "https://www.facebook.com/YetiForce-CRM-158646854306054/",
      "rel": "noreferrer noopener"
    }
  }, [_c('q-icon', {
    attrs: {
      "size": "16px",
      "name": "mdi-facebook",
      "title": "Facebook"
    }
  })], 1), _vm._v(" "), _c('q-separator', {
    staticClass: "q-mx-sm",
    attrs: {
      "dark": "",
      "vertical": ""
    }
  }), _vm._v(" "), _c('a', {
    staticClass: "q-link text-inherit",
    attrs: {
      "href": "https://github.com/YetiForceCompany/YetiForceCRM",
      "rel": "noreferrer noopener"
    }
  }, [_c('q-icon', {
    attrs: {
      "size": "16px",
      "name": "mdi-github-circle",
      "title": "Github"
    }
  })], 1), _vm._v(" "), _c('q-separator', {
    staticClass: "q-mx-sm",
    attrs: {
      "dark": "",
      "vertical": ""
    }
  }), _vm._v(" "), _c('a', {
    staticClass: "q-link text-inherit",
    attrs: {
      "href": "https://yetiforce.shop",
      "rel": "noreferrer noopener"
    }
  }, [_c('q-icon', {
    attrs: {
      "size": "18px",
      "name": "mdi-cart-outline",
      "title": "yetiforce.shop"
    }
  })], 1), _vm._v(" "), _c('q-separator', {
    staticClass: "q-mx-sm",
    attrs: {
      "dark": "",
      "vertical": ""
    }
  }), _vm._v(" "), _c('a', {
    staticClass: "q-link text-inherit",
    attrs: {
      "href": "#",
      "role": "button"
    }
  }, [_c('q-icon', {
    attrs: {
      "size": "18px",
      "name": "mdi-information-outline",
      "title": "YetiForceCRM"
    }
  })], 1)], 1)], 1);
};
var staticRenderFns = [];
var __template__ = { render: render, staticRenderFns: staticRenderFns };

export default Object.assign({}, __script__, __template__);