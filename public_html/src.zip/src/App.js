var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };

//
//
//
//
//
//
//
//
//
//

import ModuleLoader from '/src/ModuleLoader.js';
import coreStore from '/src/modules/Core/store/index.js';
import usersStore from '/src/modules/Core/modules/Users/store/index.js';
import Debug from '/src/modules/Core/modules/Debug/Debug.js';

var components = {};
var modules = [];
if (_typeof(window.modules) === 'object') {
  var flat = ModuleLoader.flattenModules(window.modules);
  components = Object.assign({}, flat.components, { Debug: Debug });
  modules = flat.modules.filter(function (module) {
    return module.fullName.substr(0, 4) === 'Core';
  });
}
modules.forEach(function (module) {
  return module.component();
});

var moduleName = 'App';
/**
 * @vue-data {Array} modules - installed modules
 */
var __script__ = {
  name: moduleName,
  components: components,
  provide: function provide() {
    var provider = {};
    var self = this;
    Object.defineProperty(provider, 'App', {
      enumerable: true,
      get: function get() {
        return self;
      }
    });
    Object.defineProperty(provider, 'debug', {
      enumerable: true,
      get: function get() {
        return self.$children[0];
      }
    });
    return provider;
  },
  data: function data() {
    return {
      modules: modules,
      config: {
        debug: {
          levels: ['log', 'info', 'notice', 'warning', 'error']
        }
      }
    };
  },
  created: function created() {
    this.$store.registerModule('Core', ModuleLoader.prepareStoreNames('Core', coreStore));
    this.config.debug.levels = window.env.Debug.levels.map(function (level) {
      return level;
    });
    this.$store.registerModule(['Core', 'Users'], ModuleLoader.prepareStoreNames(moduleName, usersStore));
    this.$store.commit(mutations.Core.Users.isLoggedIn, window.env.Users.isLoggedIn);
  }
};

var render = function render() {
  var _vm = this;var _h = _vm.$createElement;var _c = _vm._self._c || _h;
  return _c('div', {
    attrs: {
      "id": "app"
    }
  }, [_c('debug', {
    attrs: {
      "levels": _vm.config.debug.levels
    }
  }), _vm._v(" "), _c('div', {
    staticClass: "modules",
    staticStyle: {
      "display": "none"
    }
  }, _vm._l(_vm.modules, function (module) {
    return _c(module.component, {
      key: module.fullName,
      tag: "component"
    });
  }), 1), _vm._v(" "), _c('router-view')], 1);
};
var staticRenderFns = [];
var __template__ = { render: render, staticRenderFns: staticRenderFns };

export default Object.assign({}, __script__, __template__);