//
//
//
//
//
//
//
//
//
//
//
//
//
//

var __script__ = {
  name: 'YfBreadcrumbs'
};

var render = function render() {
  var _vm = this;var _h = _vm.$createElement;var _c = _vm._self._c || _h;
  return _c('q-breadcrumbs', {
    class: [_vm.$style.breadcrumbs, ''],
    attrs: {
      "active-color": "info"
    }
  }, [_c('q-breadcrumbs-el', {
    attrs: {
      "icon": "mdi-home",
      "to": '/'
    }
  }), _vm._v(" "), _vm._l(_vm.$route.matched, function (route) {
    return route.path && route.path.split('/').pop() ? _c('q-breadcrumbs-el', {
      key: route.name,
      attrs: {
        "label": route.path.split('/').pop(),
        "to": route.path
      }
    }) : _vm._e();
  })], 2);
};
var staticRenderFns = [];
var __template__ = { render: render, staticRenderFns: staticRenderFns };

export default Object.assign({}, __script__, __template__);