<template>
  <div id="app">
    <debug :levels="config.debug.levels" />
    <div class="modules" style="display:none">
      <component v-for="module in modules" :is="module.component" :key="module.fullName"></component>
    </div>
    <router-view />
  </div>
</template>

<script>
import ModuleLoader from '/src/ModuleLoader.js'
import coreStore from '/src/modules/Core/store/index.js'
import usersStore from '/src/modules/Core/modules/Users/store/index.js'
import Debug from '/src/modules/Core/modules/Debug/Debug.js'

let components = {}
let modules = []
if (typeof window.modules === 'object') {
  const flat = ModuleLoader.flattenModules(window.modules)
  components = { ...flat.components, Debug }
  modules = flat.modules.filter(module => {
    return module.fullName.substr(0, 4) === 'Core'
  })
}
modules.forEach(module => module.component())

const moduleName = 'App'
/**
 * @vue-data {Array} modules - installed modules
 */
export default {
  name: moduleName,
  components,
  provide() {
    const provider = {}
    const self = this
    Object.defineProperty(provider, 'App', {
      enumerable: true,
      get: () => self
    })
    Object.defineProperty(provider, 'debug', {
      enumerable: true,
      get: () => self.$children[0]
    })
    return provider
  },
  data() {
    return {
      modules,
      config: {
        debug: {
          levels: ['log', 'info', 'notice', 'warning', 'error']
        }
      }
    }
  },
  created() {
    this.$store.registerModule('Core', ModuleLoader.prepareStoreNames('Core', coreStore))
    this.config.debug.levels = window.env.Debug.levels.map(level => level)
    this.$store.registerModule(['Core', 'Users'], ModuleLoader.prepareStoreNames(moduleName, usersStore))
    this.$store.commit(mutations.Core.Users.isLoggedIn, window.env.Users.isLoggedIn)
  }
}
</script>

<style></style>
