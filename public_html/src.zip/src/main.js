import App from './App.js'
import createStore from '/src/store/index.js'
import createRouter from '/src/router/index.js'

const store = createStore()
const router = createRouter({ store })
store.$router = router

new Vue({
  el: '#app',
  render: h => h(App),
  store,
  router
})
