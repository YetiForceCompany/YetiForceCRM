//
//

import ModuleLoader from '/src/ModuleLoader.js';
import store from './store/index.js';
import mutations from '/src/store/mutations.js';
import getters from '/src/store/getters.js';

var moduleName = 'Core.Users';
var __script__ = {
  name: moduleName,
  created: function created() {
    // user store is registered in App.vue
  }
};

var render = function render() {
  var _vm = this;var _h = _vm.$createElement;var _c = _vm._self._c || _h;
  return _c("div");
};
var staticRenderFns = [];
var __template__ = { render: render, staticRenderFns: staticRenderFns };

export default Object.assign({}, __script__, __template__);