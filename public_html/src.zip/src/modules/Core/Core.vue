<!-- /* {[The file is published on the basis of YetiForce Public License 3.0 that can be found in the following directory: licenses/LicenseEN.txt or yetiforce.com]} */ -->
<template></template>
<script>
const moduleName = 'Core'
export default {
  name: moduleName,
  created() {
    // store for core module is registered inside App module
  }
}
</script>
