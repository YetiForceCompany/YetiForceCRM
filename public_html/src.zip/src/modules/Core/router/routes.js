export default [
  {
    name: 'Core',
    parent: 'App',
    path: '/',
    componentPath: 'layouts/Core'
  }
]
