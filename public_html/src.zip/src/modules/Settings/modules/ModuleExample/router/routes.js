export default [
  {
    name: 'Settings.ModuleExample',
    parent: 'Settings',
    path: 'module-example',
    componentPath: 'pages/ModuleExample'
  }
]
