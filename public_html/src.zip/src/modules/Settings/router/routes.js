export default [
  {
    name: 'Settings',
    parent: 'App',
    path: 'settings',
    componentPath: 'layouts/Settings'
  }
]
