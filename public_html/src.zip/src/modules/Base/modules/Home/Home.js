//
//

import mutations from '/src/store/mutations.js';

var moduleName = 'Base.Home';
var __script__ = {
  name: moduleName,
  mounted: function mounted() {
    this.$store.commit(mutations.Core.Menu.addItem, {
      path: '/home',
      icon: 'mdi-home',
      label: 'Home',
      children: []
    });
  }
};

var render = function render() {
  var _vm = this;var _h = _vm.$createElement;var _c = _vm._self._c || _h;
  return _c("div");
};
var staticRenderFns = [];
var __template__ = { render: render, staticRenderFns: staticRenderFns };

export default Object.assign({}, __script__, __template__);