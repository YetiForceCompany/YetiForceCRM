//
//
//
//
//
//
//
//
//

var __script__ = {
  name: 'Base.Layouts.Base'
};

var render = function render() {
  var _vm = this;var _h = _vm.$createElement;var _c = _vm._self._c || _h;
  return _c('q-page', {
    attrs: {
      "padding": ""
    }
  }, [_c('router-view')], 1);
};
var staticRenderFns = [];
var __template__ = { render: render, staticRenderFns: staticRenderFns };

export default Object.assign({}, __script__, __template__);